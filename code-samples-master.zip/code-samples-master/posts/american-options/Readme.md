To build you will need to download CUB.

To do this run the following command from the code-samples directory:

%> git submodule update --init --recursive

You can either build with Visual Studio (we provide solutions for VS2010 and VS2012) on Windows or make on Linux.

You need CUDA 5.5 to build with Visual Studio.

## License

These examples are released under the BSD open source license.  Refer to license.txt in the root of the parallel-forall/code-samples repository for full details.


var searchData=
[
  ['initialize',['Initialize',['../Host_8c.html#a0ea9f99f85b380e912940f351366a862',1,'Initialize(int *argc, char ***argv, int *rank, int *size):&#160;Host.c'],['../Jacobi_8h.html#a0ea9f99f85b380e912940f351366a862',1,'Initialize(int *argc, char ***argv, int *rank, int *size):&#160;Host.c']]],
  ['initializedatachunk',['InitializeDataChunk',['../Host_8c.html#a63442a950638ea4accb5dcb5ad7a8b87',1,'InitializeDataChunk(int topSizeY, int topIdxY, const int2 *domSize, const int *neighbors, cudaStream_t *copyStream, real *devBlocks[2], real *devSideEdges[2], real *devHaloLines[2], real *hostSendLines[2], real *hostRecvLines[2], real **devResidue):&#160;Host.c'],['../Jacobi_8h.html#a63442a950638ea4accb5dcb5ad7a8b87',1,'InitializeDataChunk(int topSizeY, int topIdxY, const int2 *domSize, const int *neighbors, cudaStream_t *copyStream, real *devBlocks[2], real *devSideEdges[2], real *devHaloLines[2], real *hostSendLines[2], real *hostRecvLines[2], real **devResidue):&#160;Host.c']]],
  ['input_2ec',['Input.c',['../Input_8c.html',1,'']]]
];

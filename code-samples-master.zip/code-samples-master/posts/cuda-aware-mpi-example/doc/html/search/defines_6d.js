var searchData=
[
  ['min_5fdom_5fsize',['MIN_DOM_SIZE',['../Jacobi_8h.html#a05512809cad5b2530798ada1a5f06a83',1,'Jacobi.h']]],
  ['mpi_5fmaster_5frank',['MPI_MASTER_RANK',['../Jacobi_8h.html#a30c87e11fd7fecbcda306bb0b73ef320',1,'Jacobi.h']]]
];

var searchData=
[
  ['jacobi_2ec',['Jacobi.c',['../Jacobi_8c.html',1,'']]],
  ['jacobi_2eh',['Jacobi.h',['../Jacobi_8h.html',1,'']]]
];

var searchData=
[
  ['finalize',['Finalize',['../Host_8c.html#ad25cf65f450abbc68de1a6409b0c92ba',1,'Finalize(real *devBlocks[2], real *devSideEdges[2], real *devHaloLines[2], real *hostSendLines[2], real *hostRecvLines[2], real *devResidue, cudaStream_t copyStream):&#160;Host.c'],['../Jacobi_8h.html#ad25cf65f450abbc68de1a6409b0c92ba',1,'Finalize(real *devBlocks[2], real *devSideEdges[2], real *devHaloLines[2], real *hostSendLines[2], real *hostRecvLines[2], real *devResidue, cudaStream_t copyStream):&#160;Host.c']]]
];

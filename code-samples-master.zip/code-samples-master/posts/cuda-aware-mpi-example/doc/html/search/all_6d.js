var searchData=
[
  ['main',['main',['../Jacobi_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'Jacobi.c']]],
  ['min_5fdom_5fsize',['MIN_DOM_SIZE',['../Jacobi_8h.html#a05512809cad5b2530798ada1a5f06a83',1,'Jacobi.h']]],
  ['mpi_5fmaster_5frank',['MPI_MASTER_RANK',['../Jacobi_8h.html#a30c87e11fd7fecbcda306bb0b73ef320',1,'Jacobi.h']]]
];

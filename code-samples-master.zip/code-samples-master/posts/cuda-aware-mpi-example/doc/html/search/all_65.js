var searchData=
[
  ['env_5flocal_5frank',['ENV_LOCAL_RANK',['../Jacobi_8h.html#a1cf673c1febd6ac97dd8aefadf00b5f7',1,'Jacobi.h']]],
  ['exchangehalos',['ExchangeHalos',['../CUDA__Aware__MPI_8c.html#a1dc0674ebcbca5a781885f2204d78251',1,'ExchangeHalos(MPI_Comm cartComm, real *devSend, real *hostSend, real *hostRecv, real *devRecv, int neighbor, int elemCount):&#160;CUDA_Aware_MPI.c'],['../CUDA__Normal__MPI_8c.html#a1dc0674ebcbca5a781885f2204d78251',1,'ExchangeHalos(MPI_Comm cartComm, real *devSend, real *hostSend, real *hostRecv, real *devRecv, int neighbor, int elemCount):&#160;CUDA_Normal_MPI.c'],['../Jacobi_8h.html#a1dc0674ebcbca5a781885f2204d78251',1,'ExchangeHalos(MPI_Comm cartComm, real *devSend, real *hostSend, real *hostRecv, real *devRecv, int neighbor, int elemCount):&#160;CUDA_Aware_MPI.c']]]
];

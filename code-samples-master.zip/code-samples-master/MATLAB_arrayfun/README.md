Companion Code for "High-Performance MATLAB with GPU Acceleration" by Joss Knight
============================

This folder contains source code from the NVIDIA Parallel Forall Blog post on MATLAB by Joss Knight (The Mathworks) entitled [High-Performance MATLAB with GPU Acceleration](http://developer.nvidia.com/parallel-forall/high-performance-matlab-gpu-acceleration).

License
-------

These examples are released under the BSD open source license.  Refer to license.txt in this directory for full details.

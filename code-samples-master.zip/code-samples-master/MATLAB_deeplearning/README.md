# Companion Code for "Deep Learning for Computer Vision with MATLAB"

This folder contains source code from the NVIDIA Parallel Forall Blog post [Deep Learning for Computer Vision with MATLAB](http://nvda.ly/TSOT0) by Shashank Prasanna (The Mathworks).

## License

These examples are released under the BSD open source license.  Refer to license.txt in this directory for full details.

# Example of C++11 in CUDA device code

This code depends on [cpp11-range](https://github.com/harrism/cpp11-range) as a submodule.  Before building, you need to run the following commands from the "code-samples" base directory (parent of this example):

    git submodule init
    git submodule update

